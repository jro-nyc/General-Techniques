opErrors = true;

fName = 'John';
initial = '';
lName = 'Doe';
suffix = '';
address = '126 Macdougal street, #2C';
city = 'New York';
state = 'NY';
zip = '10010';
email = 'jj@optimost.com';
emailConfirm = '';
phone1Area = '212';
phone1Prefix = '555';
phone1Suffix = '1234';
phone2Area = '617';
phone2Prefix = '259';
phone2Suffix = '0389';

loanType = 'home eq';
propState= 'MD';
propZip = '21228';
propType = 'Townhouse';
propUse = 'Investment';
propValue = '265,000';

grossIncome = '60,000';
monthlyPayments =  '703';
workStatus = 'Employed';
bankruptcy = false;
credit = 'excellent';
secondMtge = true;
mtgesToRefinance = 'first';
firstMtgeBalance = '45,000';
firstMtgeMonthly = '654';
secondMtgeBalance = '';
secondMtgeMonthly = '';
cashOut = '20,000';
rateType = 'fixed';
timing = '45';


err_fName = true;
err_initial = true;
err_suffix = true;
err_lName = true;;
err_address = true;
err_city = true;
err_state = true;
err_zip = true;
err_email = true;
err_emailConfirm = true;

err_phone1 = true;
err_phone2 = true;


err_loanType = true;
err_propState = true;
err_propZip = true;
err_propType = true;
err_propUse = true;
err_propValue = true;

err_grossIncome = true;
err_monthlyPayments = true;
err_workStatus = true;
err_bankruptcy = true;
err_credit = true;
err_secondMtge = true;
err_mtgesToRefinance = true;
err_firstMtgeBalance = true;
err_firstMtgeMonthly = true;
err_secondMtgeBalance = true;
err_secondMtgeMonthly = true;
err_cashOut = true;
err_rateType = true;
err_timing = true;


msg_fName = 'You must enter your First Name';
msg_initial = '';
msg_suffix = '';
msg_lName = 'You must enter your Last Name';
msg_address = 'You must enter your address';
msg_city = 'You must enter your city';
msg_state = 'You must enter your state';
msg_zip = 'You must enter your zip';
msg_email = 'You must enter your email address';
msg_emailConfirm = 'You must confirm your email address';


msg_phone1 = 'You must enter a valid primary phone';
msg_phone2 = '';
msg_loanType = 'You select a Loan Type';
msg_propState= 'A State name is required for the property.';
msg_propZip = 'Please enter a Zip Code. Zip Code must be 5 numeric characters. ';
msg_propType = 'You select a Property Type';
msg_propUse = 'You select how you will use this property';
msg_propValue = 'You must enter the estimated value of the property.';

msg_grossIncome = 'You must enter your Gross Income';
msg_monthlyPayments = 'You must enter your monthly payments';
msg_workStatus = 'You must enter your work status';
msg_bankruptcy = 'Have you gone into bankruptcy';
msg_credit = 'You must enter your credit history';
msg_secondMtge = 'Do you have a second mortgage';
msg_mtgesToRefinance = 'Please tell us which mortgage(s) you wish to refinance.';
msg_firstMtgeBalance = 'You must enter your first mortgage balance';
msg_firstMtgeMonthly = 'You must enter your first mortgage monthly payments';
msg_secondMtgeBalance = 'You must enter your second mortgage balance';
msg_secondMtgeMonthly = 'You must enter your second mortgage monthly payments';
msg_cashOut = 'You must enter a valid amount (this may be 0) for additional cash back.';
msg_rateType = 'You must enter the type of rate you want';
msg_timing = 'You must enter when you need the loan';
