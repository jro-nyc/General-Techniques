opErrors = false;

fName = '';
initial = '';
suffix = '';
lName = '';
address = '';
city = '';
state = '';
zip = '';
email = '';
emailConfirm = '';
phone1Area = '';
phone1Prefix = '';
phone1Suffix = '';
phone2Area = '';
phone2Prefix = '';
phone2Suffix = '';

loanType = '';
propState= '';
propZip = '';
propType = '';
propUse = '';
propValue = 

grossIncome = '';
monthlyPayments =  '';
workStatus = '';
bankruptcy = '';
credit = '';
secondMtge = '';
mtgesToRefinance = '';
firstMtgeBalance = '';
firstMtgeMonthly = '';
secondMtgeBalance = '';
secondMtgeMonthly = '';
cashOut = '';
rateType = '';
timing = '';


err_fName = false;
err_initial = false;
err_suffix = false;
err_lName = false;;
err_address = false;
err_city = false;
err_state = false;
err_zip = false;
err_email = false;
err_emailConfirm = false;

err_phone1 = false;
err_phone2 = false;

err_loanType = false;
err_propState = false;
err_propZip = false;
err_propType = false;
err_propUse = false;
err_propValue = false;

err_grossIncome = false;
err_monthlyPayments = false;
err_workStatus = false;
err_bankruptcy = false;
err_credit = false;
err_secondMtge = false;
err_mtgesToRefinance = false;
err_firstMtgeBalance = false;
err_firstMtgeMonthly = false;
err_secondMtgeBalance = false;
err_secondMtgeMonthly = false;
err_cashOut = false;
err_rateType = false;
err_timing = false;


msg_fName = '';
msg_initial = '';
msg_suffix = '';
msg_lName = '';
msg_address = '';
msg_city = '';
msg_state = '';
msg_zip = '';
msg_email = '';
msg_emailConfirm = '';


msg_phone1 = '';
msg_phone2 = '';
msg_loanType = '';
msg_propState= '';
msg_propZip = '';
msg_propType = '';
msg_propUse = '';
msg_propValue = 

msg_grossIncome = '';
msg_monthlyPayments = '';
msg_workStatus = '';
msg_bankruptcy = '';
msg_credit = '';
msg_secondMtge = '';
msg_mtgesToRefinance = '';
msg_firstMtgeBalance = '';
msg_firstMtgeMonthly = '';
msg_secondMtgeBalance = '';
msg_secondMtgeMonthly = '';
msg_cashOut = '';
msg_rateType = '';
msg_timing = '';
