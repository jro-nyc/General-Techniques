/* assuming you already have XHConn.js included in your HTML file */

var myConn = new XHConn();

if (!myConn) alert("XMLHTTP not available. Try a newer/better browser.");

var fnWhenDone = function (oXML) { alert(oXML.responseText); };

myConn.connect("mypage.php", "POST", "foo=bar&baz=qux", fnWhenDone);
