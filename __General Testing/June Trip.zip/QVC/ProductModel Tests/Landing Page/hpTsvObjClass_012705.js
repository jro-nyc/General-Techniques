// override oto display by using oto=no, or oto=yes in the homepage url
var hURL = new String(document.URL);
if(hURL.indexOf('oto=no') != -1)
	GetTSVStatus = function () { return 'instock-soldout'; }; 
else if(hURL.indexOf('oto=yes') != -1)
	GetTSVStatus = function () { return 'waitlist-instock'; }; 

//sub class for content/tsv_waitlist container
hpTsvSmallObj.prototype = new hpObj();
function hpTsvSmallObj()
{

}



//method to set art
hpTsvSmallObj.prototype.setArt = function(sArt)  
{	
	if(TSVOTOStatus()) //OTO not acitve, so set specified art
	{
		this.sArt = sArt;
	}
	else //OTO is acitve, so set TSV art
	{
		this.sArt = hpcont[0].getArt();
	}	
}

//method to set copy
hpTsvSmallObj.prototype.setCopy = function(sCopy)  
{
	if(TSVOTOStatus()) //OTO not acitve, so set specified copy
	{
		this.sCopy = sCopy;
	}
	else //OTO is acitve, so set TSV copy
	{
		this.sCopy = hpcont[0].getCopy();
	}
}

//method to set link
hpTsvSmallObj.prototype.setLink = function(sLink)  
{
	if(TSVOTOStatus()) //OTO not acitve, so set specified link
	{
		this.sLink = sLink;
	}
	else //OTO is acitve, so set TSV link
	{
		this.sLink = hpcont[0].getLink();
	}
}


// figures out of there is an oto
function TSVOTOStatus(){

     switch (GetTSVStatus()) {
	case "instock-soldout":
		return 1;
		break;
	case "instock-instock":
		return 0;
		break;
	case "waitlist-instock":
		return 0;
		break;				
	default:
		return 1;
		break;
     }

}

// displays large tsv image
function displayOTOLargeImage() {

	TSVLink 	= '/asp/frameset.asp?nest=/scripts/detail.dll?frames=y!item=oto&tpl=oto&tmp=hp&cont=oto&cm_re=HP-_-CONTAINERS-_-TSV:OTO&cm_scid=PROM';
	TSVDesc		= formatedTSVDesc();
	TSVAlt  	= GetOTODesc();
	TSVbgcolor 	= 'FFFFFF';
	TSVImage 	= getOtoImage();
	
	document.write('<img src="/qvc/gif/shim.gif" width="8" height="9" align="top"><br>');
	document.write('<table width="95%" border="1" cellspacing="0" cellpadding="0" bordercolor="#d9b77a" bgcolor="#FFFFFF">');
	document.write('<tr>');
	document.write('<td align="center" valign="top" background="/qvc/gif/hp/OTO_main_shim_0330.gif" bgcolor="#' + TSVbgcolor + '"><a href="' + TSVLink + '" class="caption"><img src="/qvc/gif/hp/OTO_main_image_0330.gif" name="OtoTopMiddle" height="102" width="270" border="0" alt="' + TSVAlt + '"><br><img src="' + TSVImage + '" name="otomainimage" height="200" width="225" border="0" alt="' + TSVAlt + '"><br><img src="/qvc/gif/shim.gif" width="1" height="12" border="0"><br>' + TSVDesc + '<br><img src="/qvc/gif/shim.gif" width="1" height="12" border="0"></a><\/td>');
	document.write('</tr>');
	document.write('</table>');
	document.write('<img src="/qvc/gif/shim.gif" width="8" height="9">');
	document.close();
	
	// if OTO image is not avail, switch OTO design if
	checkNoImage();

}

// given an item number, returns the image url for the "s" sized image.
function getOtoImage()
{
	otoPic = GetOTOPic(); //get OTO picture src
  //alert(otoPic);
	if(otoPic == '/qvc/gif/hp/hp_oto.gif') // no OTO image available
	{
		OtoImage = '/qvc/gif/hp/OTO_large_noimage.gif';
	}
	else // OTO image available, and change image size and default image to giant OTO logo
	{
		var re = new RegExp ('defaultImage=/qvc/gif/no_image_sm.gif', 'gi') ;
		var OtoImage = otoPic.replace(re, 'defaultImage=/qvc/gif/hp/OTO_large_noimage.gif') ;
	
		var re2 = new RegExp ('wid=128', 'gi') ;
		OtoImage = OtoImage.replace(re2, 'wid=225') ;
	}
	return OtoImage
}

function formatedTSVDesc()
{
	var fullTsvDesc = GetOTODesc();
	
	if(fullTsvDesc.indexOf("$") > 1) // price is included in the description
	{
		var OtoPrice = fullTsvDesc.substring(fullTsvDesc.indexOf("$"));
		var formatedDesc = '<DIV CLASS="caption"><font color="#BB0000"><b>One Time Only Price: ' + OtoPrice + '</b></font><br>' + fullTsvDesc.substring(0, fullTsvDesc.indexOf("$")) + '</div>';
		
	}	
	else // no price is available b/c it is a group item
	{
		var formatedDesc = fullTsvDesc  + "<br><br>";
	}
	return formatedDesc;
}

function checkNoImage()
{

  //alert(otoPic);
	if(otoPic.indexOf('images/oto_home.gif') != -1) // no OTO image is available
	{	// switch main OTO image to generic OTO logo
		TSVImage = new Image(); 
		TSVImage.src = "/qvc/gif/hp/OTO_large_noimage.gif";
		document.images.otomainimage.src = TSVImage.src;
	
		// switch top part of OTO design so no oto logo is in the image
		var topImage = new Image();
		topImage.src = "/qvc/gif/hp/OTO_main_image_nologo_0908.gif";
		document.images.OtoTopMiddle.src = topImage.src;	
	}
	

}

// display linked shim over TSV logo
function writeTsvLogoShim() {
	if(TSVOTOStatus())
		document.write('<a href="' + TSVLink + '"><img src="/qvc/gif/shim.gif" height="75" width="95" border="0" alt="' + TSVAlt + '"></a>');
}
