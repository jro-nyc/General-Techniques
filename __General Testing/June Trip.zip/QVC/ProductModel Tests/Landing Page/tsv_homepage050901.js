if(self!=top) {
	top.location="http://www.qvc.com";
}

function ValidateSearchRequest(f) {
	select = f.SearchClass; // get the navigation class number attribute
	option = select.options[select.selectedIndex].value; // get the selected option
	if(option=="3225") // add department numbers using "or" (example: option=="3225" || option=="1196") here whenever you add a department class to the search dropdown
	{
		f.CLASSLEVEL.value="2";	// set the CLASSLEVEL URL query string to "2" since QVCSearch.aspx needs that parameter for a department search
	}
	
	if(f.txtDesc.value!=""){
	return true;
	} else {
	alert("Please enter one or more search words before clicking SEARCH.");return false;
	}
}

function isRealBrowser()
{
	if ((navigator.userAgent.indexOf("MSIE 3") != -1) || (navigator.userAgent.indexOf("Mozilla/2") != -1))
	{
		return false;
	}

	return true;
}

function open_window(url){
      var new_win = window.open(url, "video", 'toolbar=0,location=0,directories=0,status=0,menubar=0,scrollbars=0,resizable=0,width=320,height=330,left=230,top=210');
	new_win.focus();
}

function open_feature(url, specs, name){
	if (name == null || name == "")
	{
		name = "win";
	}

      var new_win = window.open(url, name, specs);
	new_win.focus();
}


function change(url) {
	document.location = url;
}

/**************************************************/
/***        BEGIN NEW TSV FUNCTIONS        	***/
/***					   	***/
/*** These functions contain the four main 	***/
/*** chunks of content for the homepage:	***/
/*** -getTSV(): gets the TSV layout		***/
/*** -getOTO(): gets the OTO layout		***/
/*** -getPromo(): gets the Promo layout		***/
/*** -getBigPromo(): gets full-size Promo layout***/
/**************************************************/

function getTSV(){

	//TSV block
	document.write('<img src="/qvc/gif/shim.gif" width="8" height="20"><table width="95%" border="1" cellspacing="0" cellpadding="0" bordercolor="#CC6600" bgcolor="#FFFFFF" align="center" height="160">');
	document.write('<tr align="center">');
	document.write('<td height="153">');
	document.write('<table width="95%" border="0" cellspacing="0" cellpadding="0">');
	document.write('<tr align="center">');
	var tsvpic = new String (AlwaysGetTSVPic());
	document.write('<td width="147"><a href="/asp/frameset.asp?dd=/hp/hp_dd.html&nest=/scripts/detail.dll?cont=tsvso!tmp=hp!frames=y!tpl=tsv!item=tsv%252521"><img src="'+ tsvpic +'" name="tsvimg" border="0" width="128" vspace="3" alt="Today\'s Special Value" hspace="5"></a></td>');
	document.write('<td class="caption" width="100%"><a href="/asp/frameset.asp?dd=/hp/hp_dd.html&nest=/scripts/detail.dll?cont=tsvso!tmp=hp!frames=y!tpl=tsv!item=tsv%252521" class="caption">');
	document.write('<img name="tsvheader" src="/qvc/gif/hp/hp_tsvc_logo.gif" width="82" height="52" vspace="5" border="0"><br>');
	var tsvdesc = new String(AlwaysGetTSVDesc());
	document.write(tsvdesc);
	document.write('<BR><B>ONE DAY ONLY</B>');
	document.write('</a></td></tr></table></td></tr></table>');
	document.close();

}

function getOTO(){

	//OTO Block
	document.write('<img src="/qvc/gif/shim.gif" width="8" height="8"><table width="95%" border="1" cellspacing="0" cellpadding="0" bordercolor="#CC6600" bgcolor="#FFFFFF" align="center" height="160">');
	document.write('<tr align="center">');
	document.write('<td height="153">');
	document.write('<table width="95%" border="0" cellspacing="0" cellpadding="0">');
	document.write('<tr align="center">');
	var otopic = new String (GetOTOPic());
	document.write('<td width="147"><a href="/asp/frameset.asp?dd=/hp/hp_dd.html&nest=/scripts/detail.dll?frames=y!tpl=tsv!item=tsv!tmp=hp!cont=oto"><img src="'+ otopic +'" name="otoimg" border="0" width="128" vspace="3" alt="One Time Only" hspace="5"></a></td>');
	document.write('<td class="caption" width="100%"><a href="/asp/frameset.asp?dd=/hp/hp_dd.html&nest=/scripts/detail.dll?frames=y!tpl=tsv!item=tsv!tmp=hp!cont=oto" class="caption">');
	document.write('<img name="tsvheader" src="/qvc/gif/hp/hp_otoc_gif.gif" width="88" height="52" vspace="5" border="0"><br>');
	var otodesc = new String(GetOTODesc());
	document.write(otodesc);
	document.write('</a></td></tr></table></td></tr></table>');
	document.close();

}

function getPromo(){

	//Promo block
	document.write('<img src="/qvc/gif/shim.gif" width="8" height="25"><table width="95%" border="1" cellspacing="0" cellpadding="0" bordercolor="#CC6600" bgcolor="#FFFFFF" align="center" height="160">');
	document.write('<tr align="center">');
	document.write('<td height="153">');
	document.write('<table width="95%" border="0" cellspacing="0" cellpadding="0">');
	document.write('<tr align="center">');
	document.write('<td width="147"><a href="/asp/frameset.asp?dd=/hp/hp_dd.html&nest=/scripts/drilldown.dll?class=1364&frame=right&tmp=hp&cont=ss"><img src="/qvc/gif/hp/showcase_savings_logo.gif" name="tsvimg" border="0" width="136" vspace="3" alt="Showcase of Savings" hspace="5"></a></td>');
	document.write('<td class="caption" width="100%"><a href="/asp/frameset.asp?dd=/hp/hp_dd.html&nest=/scripts/drilldown.dll?class=1364&frame=right&tmp=hp&cont=ss" class="caption">');
	document.write('See our <i>Try Me</i>, <i>While Supplies Last</i>, and more specially priced items...</a></td></tr></table></td></tr></table>');
	document.close();

}


function getBigPromo(){

	document.write('<img src="/qvc/gif/shim.gif" width="8" height="9" align="top"><br><table width="95%" border="1" cellspacing="0" cellpadding="2" bordercolor="#d9b77a" bgcolor="#FFFFFF">');
	document.write('<tr><td background="/qvc/gif/hp/showcase_headline_0604_bg.gif" bgcolor="#D13333" class="background"><a href="/asp/frameset.asp?dd=/hp/hp_dd.html&nest=/scripts/drilldown.dll?class=1364&frame=right&tmp=hp&cont=ss"> ');
	document.write('<img src="/qvc/gif/shim.gif" height="345" width="265" border="0" alt="Savings Showcase"></a></td>');
	document.write('</tr></table>');

}

/***         END NEW TSV FUNCTIONS       ***/


/***        END OLD TSV FUNCTIONS        ***/

function MM_reloadPage(inib) {  //reloads the window if Nav4 resized
  if (inib==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}


//MM_reloadPage(true);

// displays the iQVC logo if "iqvc" is found in the URL
function getQVCLogo() {
	var sURL = new String(top.location).toLowerCase(); // gets the URL
	if(sURL.indexOf('iqvc') >= 0) return('<img src="/qvc/gif/hp/iqvc_qual_val_con.gif" width="124" height="68" alt="iQVC: Quality. Value. Convenience.">');
	else return('<img src="/qvc/gif/hp/qvc_logo.gif" width="188" height="45" alt="QVC: Quality. Value. Convenience.">');
}

function displayiQVCFooter() {
	var sURL = new String(top.location).toLowerCase(); // gets the URL
	if(sURL.indexOf('iqvc') >= 0) return('<img src="/qvc/gif/hp/iqvc_com_v2.gif" width="58" height="13" alt="iQVC.com"><br><br>');
	else return('<img src="/qvc/gif/shim.gif" width="1" height="1">');
}

//tour open window link
function open_tour(url, specs){
      var new_tour = window.open(url, "tour", specs);
	new_tour.focus();
}

// ****************************************
// LunchTime Specials Automation Functions
// ****************************************

// Display homepage before, during or after LTS depending on the URL parameters
var head_URL = new String(document.URL);

if(head_URL.indexOf('lts=no') != -1) 	    // if "lts=no" is found in the URL, do not display LTS.
	serverDayHour = 'Friday,10';
else if(head_URL.indexOf('lts=pre') != -1)  // if "lts=pre" is found in the URL, do not display LTS, display cont. 2 before LTS.
	serverDayHour = 'Friday,10';
else if(head_URL.indexOf('lts=post') != -1) // if "lts=post" is found in the URL, do not display LTS, display cont. 2 after LTS.
	serverDayHour = 'Friday,15';
else if (head_URL.indexOf('lts=yes') != -1) // if "lts=yes" is found in the URL, display LTS.
	serverDayHour = 'Friday,12';

// if serverDayHour is defined, get the day and hour of ther server
if (window.serverDayHour) {
	var splitDayHour = serverDayHour.split(",");
	var serverDay = splitDayHour[0];
	var serverHour = splitDayHour[1] * 1; // multiply the string by 1 to convert to a number

} else { // set day and hour vars to a time when the LTS logo will not be displayed on the homepage
	var serverDay = 'Friday';
	var serverHour = 10 * 1;

}

// Define LTS image and copy HTML code in vars
var LTSimage = '<img src="/qvc/gif/hp/lts_logo_031703.gif" border="0" width="136" height="124" alt="Lunchtime Specials!">';
var LTScopy  = '<b>Lowest Prices Ever!</b><br>SAVE on select items for a limited time.';

// Compares current day/time to LTS schedule, if M-F between 11am - 3pm returns true, otherwise returns false.
function CompareTime(serverDay, serverHour)
{
	if((serverDay != "Saturday" && serverDay != "Sunday") && (serverHour >= 11 && serverHour <= 14))
		 return true;
	else return false;
}

// Writes appropriate image in file
function display_hp_image(cont)
{
	if(!(CompareTime(serverDay, serverHour)))
	{
		if(serverHour < 11)
		 document.write(defaultHPimage);
		else if(!((defaultHPimage2 == '') || (defaultHPcopy2 == '')))
		 document.write(defaultHPimage2);
		else
		document.write(defaultHPimage);
	}
	else
    document.write('<a href="/lunchtime/index.html?tmp=hp&cont=' + cont + '&cm_re=HP-_-CONTAINERS-_-' + cont + ':LTS" class="caption">' + LTSimage + '</a>');
}

// Writes appropriate copy in file
function display_hp_copy(cont)
{
	if(!(CompareTime(serverDay, serverHour)))
	{
		if(serverHour < 11)
			document.write(defaultHPcopy);
		else if(!((defaultHPcopy2 == '') || (defaultHPimage2 == '')))
			document.write(defaultHPcopy2);
		else
			document.write(defaultHPcopy);
	}
	else
    document.write('<a href="/lunchtime/index.html?tmp=hp&cont=' + cont + '&cm_re=HP-_-CONTAINERS-_-' + cont + ':LTS" class="caption">' + LTScopy + '</a>');
}

// *****  End of LTS Automation Functions  *****