//homepage object
function hpObj()
{

}

//method to display art
hpObj.prototype.displayArt = function()
{
	document.write(this.sLink + this.sArt + '</a>');
}

//method to display copy
hpObj.prototype.displayCopy = function() 
{
	document.write(this.sLink + this.sCopy + '</a>');
}

//method to get art
hpObj.prototype.getArt = function()  
{
	return this.sArt;
}

//method to get copy
hpObj.prototype.getCopy = function()  
{
	return this.sCopy;
}

//method to get link
hpObj.prototype.getLink = function()  
{
	return this.sLink;
}

//method to set art
hpObj.prototype.setArt = function(sArt)  
{
	this.sArt = sArt;
}

//method to set copy
hpObj.prototype.setCopy = function(sCopy)  
{
	this.sCopy = sCopy;
}

//method to set link
hpObj.prototype.setLink = function(sLink)  
{
	this.sLink = sLink;
}






