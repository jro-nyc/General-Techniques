function getServerTime(){
	var myTime;
  // Retrieves server time in format: Day,Date
	var hURL = new String(document.URL);
	//this is an overrid to switch out promotions using paramters in the url NOT the server time
  var override = hURL.split('time=');
	//alert(hURL);
	if (override[1] != undefined)
	{
		showTime = override[1].split('&');
		serverTime = showTime[0];
		myTime = serverTime;
	}
	else
	{
		serverTime = serverDayHour;
		sTimeArray = serverTime.split(",");
		myTime = sTimeArray[1];
	}	
	//alert(myTime);
	return myTime;
}

function displayNewPromo(spot, spotType)
{
	if (spotType == 'img')
	{
		document.write('<a href=' + spotLink[spot] + '><img src="/qvc/gif/hp/' + spotImg[spot] +'" alt="' + spotAlt[spot] + '" width="136" height="124" border="0"></a>');
	}
	else if (spotType == 'srch')
	{
		document.write('<a href="' + spotLink[spot] + '"><img src="/qvc/gif/hp/' + spotImg[spot] +'" alt="' + spotAlt[spot] + '" width="300" height="25" border="0"></a>');
	}
	else
	{
		document.write('<a href=' + spotLink[spot] + ' class="caption">' + spotCaption[spot] + '</a>');
	}
}
