var sURL = unescape(window.location.href);
var timeOut = 18 * 60 * 1000
//refresh the page after 18 minutes;
//alert(sURL)
setTimeout("top.location.href = sURL",timeOut);
//var isNS = (navigator.appName=="Netscape")?true:false;
var isNS = (navigator.userAgent.indexOf("Netscape") > -1)?true:false;

//setTimeout(window.location.reload(),timeOut);

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}



function letternumber(e)
{
	var key;
	var keychar;
	if (window.event)
	key = window.event.keyCode;
	else if (e)
	key = e.which;
	else
	return true;
	keychar = String.fromCharCode(key);
	keychar = keychar.toLowerCase();
	// control keys
	if ((key==null) || (key==0) || (key==8) || 
	(key==9) || (key==13) || (key==27) || (key==32) )
	return true;
	// alphas and numbers
	else if ((("abcdefghijklmnopqrstuvwxyz0123456789").indexOf(keychar) > -1))
	return true;
	else
	return false;
}


function numbersonly(e)
{
	var key;
	var keychar;
	if (window.event)
	key = window.event.keyCode;
	else if (e)
	key = e.which;
	else
	return true;
	keychar = String.fromCharCode(key);
	keychar = keychar.toLowerCase();
	// control keys
	if ((key==null) || (key==0) || (key==8) || 
	(key==9) || (key==13) || (key==27) )
	return true;
	// numbers
	else if ((("0123456789.").indexOf(keychar) > -1))
	return true;
	else
	return false;
}

function setWait(c,n) {
			//alert("test")
		//	 c.value = c.value.substring(0,2);
			c.focus();
			c.select();
			currValue = c.value;
			currField = c;
			nextField = n;
			 
			setTimeout("checkForNum()",100);
			}

		function checkForNum() {
		if(currField.value.length == 3 && currField.value != currValue) {
		//     alert(currField.value+":"+currValue+":"+nextField.name);
			nextField.focus();
			//nextField.select();
			
			}
		else{setTimeout("checkForNum()",5);}
}

function getPosition() {
	if (isNS)
	{
		document.forms[0].hid.value = document.body.scrollTop;
	}
	else 
	{
		document.forms[0].hid.value = document.documentElement.scrollTop;
	}
}
			
function setPosition() {
	if (isNS)
	{
		document.body.scrollTop = document.forms[0].hid.value;
	}
	else
	{
		document.documentElement.scrollTop=document.forms[0].hid.value;
	}
}

function OpenDesigner(strUrl){

	ixpos = (isNS)?window.screenX+50:window.screenLeft+50;
	iypos = (isNS)?window.screenY+50:window.screenTop+50;
	if (isNS) 
	{ myWindow = window.open(strUrl, "rDesignerWindow", 'width=748,height=500,screenX='+ixpos+',screenY='+iypos+',menubar=no,toolbar=no,resizable=no,scrollbars=no,status=no,directories=no,alwaysRaised=yes');}
	else
	{ myWindow = window.open(strUrl, "rDesignerWindow", 'width=748,height=500,left='+ixpos+',top='+iypos+',menubar=no,toolbar=no,resizable=no,scrollbars=no,status=no,directories=no,alwaysRaised=yes');}
	myWindow.focus();
}

function CheckSelectItem(){
	//debugger
	var itemCount = 0
	var i
	var count = document.forms[0].elements.length
	for (i = 0; i < count ; i++)
	{
		if (document.forms[0].elements[i].type == "checkbox")
			if(document.forms[0].elements[i].checked == true)
				itemCount += 1
	}
	
	if(itemCount > 0)
		return true
	else{
		alert("Please select one or more samples to 'Add to Cart'")
		return false
	}
	
	//return (itemCount > 0)
}

function Katrina_submit(){
	document.forms['Katrina'].submit();
}

